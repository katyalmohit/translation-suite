import 'package:voicecall/models/user.dart'; // Your User model
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:cloud_firestore/cloud_firestore.dart'; // Import Firestore

class AuthMethods {
  final firebase_auth.FirebaseAuth _auth = firebase_auth.FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance; // Firestore instance

  // Sign up method
  Future<User?> signUp(String email, String password, User user) async {
    try {
      firebase_auth.UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Create a new user model instance
      return User(
        uid: userCredential.user!.uid,
        fullName: '',
        email: email,
        phoneNumber: '',
        birthday: '',
        location: '',
      );
    } on firebase_auth.FirebaseAuthException catch (e) {
      print('Sign up error: ${e.message}');
      return null; // Return null on error
    }
  }

  // Login method
  Future<User?> login(String email, String password) async {
    try {
      firebase_auth.UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Fetch user data from Firestore
      DocumentSnapshot userDoc = await _firestore.collection('users').doc(userCredential.user!.uid).get();

      if (userDoc.exists) {
        // Return user details from Firestore
        return User(
          uid: userDoc['uid'], // Ensure this matches your Firestore data structure
          fullName: userDoc['fullName'],
          email: userDoc['email'],
          phoneNumber: userDoc['phoneNumber'],
          birthday: userDoc['birthday'],
          location: userDoc['location'],
        );
      } else {
        print('User not found in Firestore');
        return null; // User does not exist in Firestore
      }
    } on firebase_auth.FirebaseAuthException catch (e) {
      print('Login error: ${e.message}');
      return null; // Return null on error
    }
  }

  // Sign out method
  Future<void> signOut() async {
    await _auth.signOut();
  }
}
