import 'package:flutter/material.dart';
import '../widgets/customized_button.dart';
import '../widgets/customized_textfield.dart';
import '../widgets/loading_spinner.dart'; // Import loading spinner
import 'login_screen.dart';
import '../services/auth_methods.dart';
import '../services/firestore_methods.dart';
import 'package:voicecall/models/user.dart'; // Your User model

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _birthdayController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final AuthMethods _authMethods = AuthMethods();
  final FirestoreMethods _firestoreMethods = FirestoreMethods();
  bool _isLoading = false; // State for loading spinner

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: MediaQuery.of(context).size.height,
            ),
            child: IntrinsicHeight(
              child: Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color.fromARGB(255, 11, 204, 165), Color.fromARGB(255, 10, 175, 246)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Back button
                      Padding(
                        padding: const EdgeInsets.only(top: 10.0),
                        child: IconButton(
                          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Title
                      const Text(
                        "Hello! Register to get Started",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 15),

                      // Full Name Text Field
                      CustomizedTextfield(
                        myController: _fullNameController,
                        hintText: "Full Name",
                        isPassword: false,
                      ),

                      // Email Address Text Field
                      CustomizedTextfield(
                        myController: _emailController,
                        hintText: "Email Address",
                        isPassword: false,
                      ),

                      // Password Text Field
                      CustomizedTextfield(
                        myController: _passwordController,
                        hintText: "Password",
                        isPassword: true,
                        keyboardType: TextInputType.visiblePassword,
                      ),

                      // Phone Number Text Field
                      CustomizedTextfield(
                        myController: _phoneNumberController,
                        hintText: "Phone Number",
                        isPassword: false,
                        keyboardType: TextInputType.phone,
                      ),

                      // Birthday Text Field with Date Picker
                      GestureDetector(
                        onTap: () async {
                          DateTime? pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(1900),
                            lastDate: DateTime.now(),
                          );
                          if (pickedDate != null) {
                            setState(() {
                              _birthdayController.text =
                                  "${pickedDate.day}/${pickedDate.month}/${pickedDate.year}";
                            });
                          }
                        },
                        child: AbsorbPointer(
                          child: CustomizedTextfield(
                            myController: _birthdayController,
                            hintText: "Birthday (DD/MM/YYYY)",
                            isPassword: false,
                          ),
                        ),
                      ),

                      // Location Text Field
                      CustomizedTextfield(
                        myController: _locationController,
                        hintText: "Location",
                        isPassword: false,
                      ),

                      const SizedBox(height: 5),

                      // Register Button
                      Center(
                        child: _isLoading // Show loading spinner if loading
                            ? const LoadingSpinner() // Show loading spinner
                            : CustomizedButton(
                                buttonText: "Register",
                                buttonColor: const Color(0xFFEC407A), // Pink button
                                textColor: Colors.white,
                                borderRadius: 25,
                                onPressed: () async {
                                  await _registerUser(); // Call registration method
                                },
                              ),
                      ),

                      const SizedBox(height: 5),

                      // Already have an account? Login Now
                      Center(
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const LoginScreen()),
                            );
                          },
                          child: RichText(
                            text: const TextSpan(
                              text: "Already have an account? ", // Regular style
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 15,
                              ),
                              children: [
                                TextSpan(
                                  text: "Login Now", // Bold and different color
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 21, 255), // Different color
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _registerUser() async {
    String fullName = _fullNameController.text.trim();
    String email = _emailController.text.trim();
    String phoneNumber = _phoneNumberController.text.trim();
    String birthday = _birthdayController.text.trim();
    String location = _locationController.text.trim();
    String password = _passwordController.text.trim();

    // Validate form fields
    if (email.isEmpty || fullName.isEmpty || phoneNumber.isEmpty || birthday.isEmpty || location.isEmpty || password.isEmpty) {
      _showErrorDialog("Please fill out all fields.");
      return;
    }

    setState(() {
      _isLoading = true; // Start loading
    });

    // Call signup method from AuthMethods
    final errorMessage = await _authMethods.signUp(email, password, User(
      uid: '', // Placeholder, actual UID will be generated by Firebase
      fullName: fullName,
      email: email,
      phoneNumber: phoneNumber,
      birthday: birthday,
      location: location,
    ));

    if (errorMessage == null) {
      // User registration successful
      await _firestoreMethods.saveUserData(User(
        uid: email, // Replace this with the actual user ID from Firebase
        fullName: fullName,
        email: email,
        phoneNumber: phoneNumber,
        birthday: birthday,
        location: location,
      ));

      // Navigate to login screen after successful registration
      Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
    } else {
      _showErrorDialog(errorMessage as String); // Show error message
    }

    setState(() {
      _isLoading = false; // Stop loading
    });
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Error"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }
}
